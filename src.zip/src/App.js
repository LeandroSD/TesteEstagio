import React from "react";
import TopBanner from "./components/TopBanner";
import SignUp from "./components/SignUp";
import { styled } from "@material-ui/core";
import image6 from "./assets/images/image6.jpg";
import NavBar from "./components/NavBar";

const FirstScreen = styled("div")({
  backgroundImage: `url(${image6})`,
  backgroundSize: "100% 550px",
  width: "100%",
  height: "550px",
});

function App() {
  //const [name, setName] = useState("");

  //const handleChange = (event) => {
  //setName(event.target.value);
  //};

  return (
    <>
      <TopBanner />

      <NavBar></NavBar>
      <FirstScreen>
        <SignUp />
      </FirstScreen>
    </>
  );
}

export default App;
